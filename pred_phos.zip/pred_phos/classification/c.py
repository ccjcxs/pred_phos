import pandas as pd
import torch
import torch.nn as nn
from torch.optim import Adam
from sklearn.model_selection import StratifiedKFold
from sklearn.metrics import accuracy_score, roc_auc_score

# 从 Excel 文件加载数据
excel_path = 'MOL+INT.xlsx'  # 替换为你的 Excel 文件路径
data = pd.read_excel(excel_path)

# 提取局部特征和整体特征
local_features = data[['A', 'B', 'C', 'D']].to_numpy()
global_features = data[['E', 'F', 'G', 'H']].to_numpy()
labels = data['I'].to_numpy()  # 假设标签列名为 'I'

# 转换为 PyTorch 的 Tensor
local_features = torch.tensor(local_features, dtype=torch.float32)
global_features = torch.tensor(global_features, dtype=torch.float32)
labels = torch.tensor(labels, dtype=torch.float32)

# 定义前馈神经网络模型
class FeedforwardNN(nn.Module):
    def __init__(self, input_size, hidden_size, output_size):
        super(FeedforwardNN, self).__init__()
        # 定义局部特征分支
        self.local_branch = nn.Sequential(
            nn.Linear(input_size, hidden_size),
            nn.ReLU(),
            nn.Linear(hidden_size, output_size),
            nn.Sigmoid()
        )

        # 定义整体特征分支
        self.global_branch = nn.Sequential(
            nn.Linear(input_size, hidden_size),
            nn.ReLU(),
            nn.Linear(hidden_size, output_size),
            nn.Sigmoid()
        )

        # 最终分类层
        self.final_layer = nn.Linear(2 * output_size, 1)

    def forward(self, local_input, global_input):
        local_output = self.local_branch(local_input)
        global_output = self.global_branch(global_input)

        # 将两个分支的输出合并
        combined_output = torch.cat((local_output, global_output), dim=1)

        # 使用最终层进行二分类
        final_output = self.final_layer(combined_output)
        return final_output

# 设置交叉验证参数
n_splits = 10
skf = StratifiedKFold(n_splits=n_splits, shuffle=True, random_state=42)

# 初始化用于存储交叉验证结果的列表
accuracy_scores = []
auc_scores = []
std_dev_scores = []  # 用于存储标准差的列表

# 进行 10 折交叉验证
for i, (train_index, test_index) in enumerate(skf.split(local_features.numpy(), labels.numpy())):
    local_train, local_test = local_features[train_index], local_features[test_index]
    global_train, global_test = global_features[train_index], global_features[test_index]
    labels_train, labels_test = labels[train_index], labels[test_index]

    # 初始化模型
    model = FeedforwardNN(input_size=4, hidden_size=2, output_size=1)

    # 定义损失函数和优化器
    criterion = nn.BCEWithLogitsLoss()
    optimizer = Adam(model.parameters(), lr=0.01)

    # 训练模型
    num_epochs = 1000
    for epoch in range(num_epochs):
        optimizer.zero_grad()
        outputs = model(local_train, global_train)
        loss = criterion(outputs, labels_train.view(-1, 1))
        loss.backward()
        optimizer.step()

    # 在测试集上进行预测
    with torch.no_grad():
        test_outputs = model(local_test, global_test)
        predictions = (torch.sigmoid(test_outputs) > 0.5).float()

    # 计算准确率、AUC和标准差
    accuracy = accuracy_score(labels_test, predictions)
    auc = roc_auc_score(labels_test, torch.sigmoid(test_outputs))
    std_dev = predictions.std()

    # 记录每个折叠的输出
    accuracy_scores.append(accuracy)
    auc_scores.append(auc)
    std_dev_scores.append(std_dev)

    print(f"Fold {i + 1} Accuracy: {accuracy}, AUC: {auc}, Std Dev of Outputs: {std_dev}")

# 输出平均准确率、AUC和标准差
average_accuracy = sum(accuracy_scores) / n_splits
average_auc = sum(auc_scores) / n_splits
average_std_dev = sum(std_dev_scores) / n_splits

print(f"\nAverage Accuracy across {n_splits}-fold Cross-validation: {average_accuracy}")
print(f"Average AUC across {n_splits}-fold Cross-validation: {average_auc}")
print(f"Average Std Dev of Outputs across {n_splits}-fold Cross-validation: {average_std_dev}")
