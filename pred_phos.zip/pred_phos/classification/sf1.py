import pandas as pd
import torch
import torch.nn as nn
from sklearn.model_selection import StratifiedKFold
from sklearn.metrics import accuracy_score, roc_auc_score

# 从 Excel 文件加载数据
excel_path = 'name.xlsx'  # 替换为你的 Excel 文件路径
data = pd.read_excel(excel_path)

# 提取全局特征
features = data[['PC1', 'PC2', 'PC3', 'PC4', 'PC5', 'PC6', 'PC7', 'PC8']].to_numpy()
labels = data['I'].to_numpy()  # 假设标签列名为 'I'

# 转换为 PyTorch 的 Tensor
features = torch.tensor(features, dtype=torch.float32)
labels = torch.tensor(labels, dtype=torch.float32)

# 设置交叉验证参数
n_splits = 10
skf = StratifiedKFold(n_splits=n_splits, shuffle=True, random_state=42)

# 初始化用于存储交叉验证结果的列表
accuracy_scores = []
auc_scores = []
std_dev_scores = []  # 用于存储标准差的列表

# 定义前馈神经网络模型
class FeedforwardNN(nn.Module):
    def __init__(self, input_size, hidden_size, output_size):
        super(FeedforwardNN, self).__init__()
        self.fc1 = nn.Linear(input_size, hidden_size)
        self.fc2 = nn.Linear(hidden_size, output_size)

    def forward(self, x):
        x = torch.relu(self.fc1(x))
        x = torch.sigmoid(self.fc2(x))
        return x

# 进行 10 折交叉验证
for i, (train_index, test_index) in enumerate(skf.split(features.numpy(), labels.numpy())):
    train_features, test_features = features[train_index], features[test_index]
    train_labels, test_labels = labels[train_index], labels[test_index]

    # 初始化模型
    model = FeedforwardNN(input_size=8, hidden_size=2, output_size=1)
    optimizer = torch.optim.Adam(model.parameters(), lr=0.01)
    criterion = nn.BCELoss()

    # 训练模型
    num_epochs = 1000
    for epoch in range(num_epochs):
        optimizer.zero_grad()
        outputs = model(train_features)
        loss = criterion(outputs, train_labels.view(-1, 1))
        loss.backward()
        optimizer.step()

    # 在测试集上进行预测
    with torch.no_grad():
        test_outputs = model(test_features)
        predictions = (torch.sigmoid(test_outputs) > 0.5).float()

    # 计算准确率
    accuracy = accuracy_score(test_labels, predictions)
    accuracy_scores.append(accuracy)

    # 计算AUC
    auc = roc_auc_score(test_labels, torch.sigmoid(test_outputs))
    auc_scores.append(auc)

    # 计算标准差
    std_dev = predictions.std()
    std_dev_scores.append(std_dev)

    print(f"Fold {i + 1} Accuracy: {accuracy}")
    print(f"Fold {i + 1} AUC: {auc}")
    print(f"Fold {i + 1} Std Dev of Outputs: {std_dev}")

# 输出平均准确率、AUC和标准差
average_accuracy = sum(accuracy_scores) / n_splits
average_auc = sum(auc_scores) / n_splits
average_std_dev = sum(std_dev_scores) / n_splits
print(f"\nAverage Accuracy across {n_splits}-fold Cross-validation: {average_accuracy}")
print(f"Average AUC across {n_splits}-fold Cross-validation: {average_auc}")
print(f"Average Std Dev of Outputs across {n_splits}-fold Cross-validation: {average_std_dev}")
